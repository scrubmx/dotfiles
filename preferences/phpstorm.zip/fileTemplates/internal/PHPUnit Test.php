<?php 

#if (${NAMESPACE}) namespace ${NAMESPACE}; #end

#if(${NAMESPACE}) use Tests\TestCase; #end

class ${NAME} extends#if(${NAMESPACE}) TestCase #else PHPUnit_Framework_TestCase #end
{
    
}
